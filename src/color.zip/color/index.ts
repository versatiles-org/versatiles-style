import { Color } from './abstract.ts';
import { HSL } from './hsl.ts';
import { HSV } from './hsv.ts';
import { RGB } from './rgb.ts';


Color.parse = function (str: string): Color {
	const prefix = str.replace(/\d.*/, '').trim().toLowerCase();

	switch (prefix) {
		case '#':
		case 'rgb(':
		case 'rgba(':
			return RGB.parse(str);
		case 'hsl(':
		case 'hsla(':
			return HSL.parse(str);
		default:
			throw Error('Unknown color format: ' + str);
	}
}


export { Color };
