import type { HSL } from './hsl.ts';
import type { HSV } from './hsv.ts';
import type { RGB } from './rgb.ts';
import { clamp, mod } from './utils.ts';

export abstract class Color {
	static parse: (str: string) => Color;
	abstract clone(): InstanceType<typeof Color>;

	asHex(): string {
		return this.toRGB().asHex();
	}
	abstract asArray(): number[];

	abstract asHSL(): HSL;
	abstract asHSV(): HSV;
	abstract asRGB(): RGB;

	toHSL(): HSL {
		return this.asHSL();
	}
	toHSV(): HSV {
		return this.asHSV();
	}
	toRGB(): RGB {
		return this.asRGB();
	}

	gamma(value: number): RGB {
		if (value < 1e-3) value = 1e-3;
		if (value > 1e3) value = 1e3;
		const rgb = this.toRGB();
		rgb.r = Math.pow(rgb.r / 255, value) * 255;
		rgb.g = Math.pow(rgb.g / 255, value) * 255;
		rgb.b = Math.pow(rgb.b / 255, value) * 255;
		return rgb;
	}

	invert(): RGB {
		const rgb = this.toRGB();
		rgb.r = 255 - rgb.r;
		rgb.g = 255 - rgb.g;
		rgb.b = 255 - rgb.b;
		return rgb;
	}

	invertLuminosity(): HSL {
		const hsl = this.toHSL();
		hsl.l = 100 - hsl.l;
		return hsl;
	}

	rotateColor(offset: number): HSL {
		const hsl = this.toHSL();
		hsl.h = mod(hsl.h + offset, 360);
		return hsl;
	}

	saturate(ratio: number): HSL {
		const hsl = this.toHSL();
		if (ratio < 0) {
			hsl.l = clamp(hsl.l * (1 + ratio), 0, 100);
		} else {
			hsl.l = clamp(100 - (100 - hsl.l) * (1 - ratio), 0, 100);
		}
		return hsl;
	}

	contrast(value: number): RGB {
		if (value < 0) value = 0;
		if (value > 1e6) value = 1e6;
		const rgb = this.toRGB();
		rgb.r = clamp((rgb.r - 127.5) * value + 127.5, 0, 255);
		rgb.g = clamp((rgb.g - 127.5) * value + 127.5, 0, 255);
		rgb.b = clamp((rgb.b - 127.5) * value + 127.5, 0, 255);
		return rgb;
	}

	brightness(value: number): RGB {
		if (value < -1) value = -1;
		if (value > 1) value = 1;
		const a = 1 - Math.abs(value);
		const b = (value < 0) ? 0 : 255 * value;
		const rgb = this.toRGB();
		rgb.r = rgb.r * a + b;
		rgb.g = rgb.g * a + b;
		rgb.b = rgb.b * a + b;
		return rgb;
	}

	tint(value: number, tintColor: Color): RGB {
		if (value < 0) value = 0;
		if (value > 1) value = 1;
		const rgb0 = this.toRGB();
		const hsv = this.toHSV();
		hsv.h = tintColor.toHSV().h;
		const rgbNew = hsv.toRGB();

		rgbNew.r = rgb0.r * (1 - value) + value * rgbNew.r;
		rgbNew.g = rgb0.g * (1 - value) + value * rgbNew.g;
		rgbNew.b = rgb0.b * (1 - value) + value * rgbNew.b;

		return rgbNew;
	}
}
