import type { RandomColorOptions } from './random.ts';
import randomColor from './random.ts';

describe('RandomColor', () => {
	test('constructor initializes without errors', () => {
		expect(randomColor).toBeDefined();
	});

	describe('randomColor method', () => {
		test('returns correct color string for some test cases', () => {
			function t(options: RandomColorOptions): string {
				return randomColor(options).asHSL().asString();
			}
			expect(t({ hue: 'red' })).toBe('hsl(343,65%,51%)');
			expect(t({ hue: 120 })).toBe('hsl(120,77%,32%)');
			expect(t({ luminosity: 'dark' })).toBe('hsl(135,96%,31%)');
			expect(t({ saturation: 'strong' })).toBe('hsl(193,100%,24%)');
			expect(t({ opacity: 0.5 })).toBe('hsla(242,55%,42%,0.5)');
			expect(t({ seed: 'testSeed' })).toBe('hsl(185,90%,23%)');
		});

		test('consistent color generation with a seed', () => {
			const options: RandomColorOptions = { seed: 'consistentSeed' };
			const color1 = randomColor(options);
			const color2 = randomColor(options);
			expect(color1).toBe(color2);
		});

		test('different color generation without a seed', () => {
			const color1 = randomColor();
			const color2 = randomColor();
			expect(color1).not.toBe(color2);
		});
	});
});
